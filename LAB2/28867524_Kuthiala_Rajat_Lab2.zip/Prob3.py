def Prob3(x,y):
	for i in list(range(1,x+1)):
		for j in list(range(1,y+1)):
			print(j*i, end=' ')
		print()