def Prob2(x):
	for j in range(x):
		for i in range(j+1):
			print("*", end='')
		print()