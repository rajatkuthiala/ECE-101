#Farhenhite to Celcius by Rajat Kuthiala

def Prob1a(f):
	x=(f-32)*5/9
	print(x)
