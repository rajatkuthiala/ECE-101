#Average Calculator By Rajat Kuthiala


def Prob3():
	print("This program computes the average of two exam scores.")
	score1, score2 = eval(input("Enter two scores separated by a comma: "))
	average = (score1 + score2) / 2
	print("The average of the scores is:", average)

