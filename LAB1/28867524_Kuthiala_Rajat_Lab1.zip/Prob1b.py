#Celcius to Farhenhite by Rajat Kuthiala


def Prob1b(c):
	x=(9/5*c)+32
	print(x)
	