from Myro import *


def Prob1():
    #Square
    forward(1,2)
    turnRight(1,.6)
    forward(1,2)
    turnRight(1,.6)
    forward(1,2)
    turnRight(1,.6)
    forward(1,2)
    turnRight(1,.6)
    stop()
    
    #triangle
    forward(1,2)
    turnRight(1,.8)
    forward(1,2)
    turnRight(1,.8)
    forward(1,2)
    
    stop()
    
Prob1()