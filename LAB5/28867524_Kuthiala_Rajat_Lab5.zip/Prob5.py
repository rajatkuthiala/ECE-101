from Myro import *

def Prob5():
    picture=takePicture("color")
    show(picture)
    